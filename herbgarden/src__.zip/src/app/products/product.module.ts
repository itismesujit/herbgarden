// import { NgModule } from '@angular/core';
// import { ProductListComponent } from './product-list/product-list.component';
// import { ProductDetailComponent } from './product-detail/product-detail.component';
// import { ProductEditComponent } from './product-edit/product-edit.component';
// import { ReactiveFormsModule } from '@angular/forms';
// import { RouterModule } from '@angular/router';
// import { ProductDetailGuard } from './product-detail/product-detail.guard';
// import { ProductEditGuard } from './product-edit/product-edit.guard';
// import { SharedModule } from '../shared/shared.module';
// import { AuthModule } from '../auth/auth.module';
// import { HTTP_INTERCEPTORS } from '@angular/common/http';
// import { AuthInterceptor } from '../auth/auth-interceptor';



// @NgModule({
//   declarations: [
//     ProductListComponent,
//     ProductDetailComponent,
//     ProductEditComponent
//   ],
//   providers: [
//     {
//       provide: HTTP_INTERCEPTORS,
//       useClass:AuthInterceptor, multi:true
//     }
//   ],
  
//   imports: [
    
//     ReactiveFormsModule,
//     SharedModule,
//     AuthModule,
//     RouterModule.forChild([{ path:'products', component:ProductListComponent },
//     { path:'products/:id', canActivate:[ProductDetailGuard], component:ProductDetailComponent},
//     { path:'products/:id/edit',canDeactivate:[ProductEditGuard],component:ProductEditComponent }])
    
//   ]
// })
// export class ProductModule { }



import { NgModule } from '@angular/core';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { ProductEditComponent } from './product-edit/product-edit.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ProductDetailGuard } from './product-detail/product-detail.guard';
import { ProductEditGuard } from './product-edit/product-edit.guard';
import { SharedModule } from '../shared/shared.module';
import { CommonModule } from '@angular/common';
import { AuthModule } from '../auth/auth.module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from '../auth/auth-interceptor';



@NgModule({
  declarations: [
    ProductListComponent,
    ProductDetailComponent,
    ProductEditComponent
  ],
  providers:[{provide:HTTP_INTERCEPTORS, useClass:AuthInterceptor, multi:true}],
  imports: [
    
    ReactiveFormsModule,
    SharedModule,
    AuthModule,
    RouterModule.forChild([{ path:'products', component:ProductListComponent },
    { path:'products/:id', canActivate:[ProductDetailGuard], component:ProductDetailComponent},
    { path:'products/:id/edit',canDeactivate:[ProductEditGuard],component:ProductEditComponent }])
    
  ]
})
export class ProductModule { }

