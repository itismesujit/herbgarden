import { Component, OnDestroy, OnInit } from "@angular/core";
import { Subscription } from "rxjs";
import { AuthService } from "src/app/auth/auth-service";

@Component({
    selector: 'app-nav',
    templateUrl: './navigation.component.html'
  })
  
export class NavigationComponent implements OnInit, OnDestroy{
  userIsAuthenticated=false;
  private authListenerSubs$:any =Subscription;
  constructor (private authService:AuthService){}
  ngOnInit() :void {
    this.userIsAuthenticated = this.authService.getIsAuthenticated();
    this.authListenerSubs$=this.authService.getAuthStatusListener().
    subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      }
    )
  }

  // ! logout
  onLogout(){
    this.authService.logout();
  }
  
  ngOnDestroy(): void {
    this.authListenerSubs$.unsubscribe();
  }
}