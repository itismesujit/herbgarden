import { Component } from "@angular/core";

@Component({
    selector: 'app-nav',
    templateUrl: './navigation.component.html'
  })
  
export class NavigationComponent{

}