export interface AuthData {
    _id:string;
    email:string;
    password:string;
    role:string;
}
