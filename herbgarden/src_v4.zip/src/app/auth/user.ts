// /* Defines the user entity */
// export interface User {
//     id: number;
//     userName: string;
//     isAdmin: boolean;
// }

export interface User{
    email:string;
    password:string
}