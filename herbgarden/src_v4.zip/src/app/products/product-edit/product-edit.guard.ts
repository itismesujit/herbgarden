import { Injectable } from '@angular/core';
import {  CanDeactivate } from '@angular/router';

import { ProductEditComponent } from './product-edit.component';

@Injectable({
  providedIn: 'root'
})
export class ProductEditGuard implements CanDeactivate<unknown> {
  canDeactivate(component:ProductEditComponent):boolean
  {
    if(component.productForm.dirty){
      const prodName=component.product.productName || 'New Product'
      return confirm(`Would you like to navigate and loose all changes to ${prodName}`)
    }
    return true;
  }
  
}


