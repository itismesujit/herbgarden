import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { NavigationComponent } from './shared/navigation/navigation.component';
import { ErrorPageComponent } from './shared/error.component';
import { ProductModule } from './products/product.module';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { ProductDataService } from './data/product.data';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { FileuploadComponent } from './fileupload/fileupload.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavigationComponent,
    ErrorPageComponent,
    DashboardComponent,
    FileuploadComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    // InMemoryWebApiModule.forRoot(ProductDataService),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ProductModule,
    AppRoutingModule,
    StoreModule.forRoot({}, {})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
