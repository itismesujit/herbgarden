export interface IPicture {
    id:any;
    title:string;
    content:string;
    imagePath:any;
}