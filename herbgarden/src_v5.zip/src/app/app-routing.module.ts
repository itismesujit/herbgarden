import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FileuploadComponent } from './fileupload/fileupload.component';
import { HomeComponent } from './home/home.component';
import { ErrorPageComponent } from './shared/error.component';

const routes: Routes = [
  { path:'', redirectTo:'home', pathMatch:'full' },
  { path:'index', redirectTo:'home', pathMatch:'full' },
  { path:'home', component:HomeComponent },
  { path:'dash', component:DashboardComponent },
  { path:'upload', component:FileuploadComponent},
  { path:"**", component:ErrorPageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
