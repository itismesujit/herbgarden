export class Calculator{
    res=0;
    add(x:number,y:number){
        return x + y
    }
    multiply(x:number,y:number){
        return x * y;
    }
}