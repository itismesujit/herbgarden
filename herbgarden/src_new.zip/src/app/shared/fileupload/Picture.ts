export interface IPicture{
    id:string;
    title:string;
    content:string;
    imagePath:string;
}