import { Component } from "@angular/core";
import { NgForm } from "@angular/forms";

@Component({
    templateUrl:'signup.component.html'
})
export class SignUpComponent{
    isLoading=false;
    onSignUp(form:NgForm)
    {
        console.log(form.value)
    }
}