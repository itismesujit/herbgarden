import { Component } from "@angular/core";
import { NgForm } from "@angular/forms";

@Component({
    selector:'app-login',
    templateUrl:'login.component.html'
})
export class LoginComponent{
    pageTitle='Login';
    maskUserName: boolean=true;
    errorMessage="";
    login(loginForm:NgForm){
        console.log("Login successful" + loginForm.value)
    }
    cancel(){
        console.log("form reset")
    }
}