import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductDetailComponent } from './products/product-detail/product-detail.component';
import { ProductDetailGuard } from './products/product-detail/product-detail.guard';
import { ProductEditComponent } from './products/product-edit/product-edit.component';
import { ProductEditGuard } from './products/product-edit/product-edit.guard';
import { ProductListComponent } from './products/product-list/product-list.component';
import { ErrorComponent } from './shared/error/error.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'index',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'home',
    component: HomeComponent
  }, 
  {
    path: 'products',
    component: ProductListComponent
  }, {
    path: 'products/:id',
    // canActivate: [ProductDetailGuard],
    component: ProductDetailComponent
  },
  {
    path: 'products/:id/edit',
    canDeactivate:[ProductEditGuard],
    canActivate: [ProductDetailGuard],
    component: ProductEditComponent
  },
  {
    path: '**',
    component: ErrorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
