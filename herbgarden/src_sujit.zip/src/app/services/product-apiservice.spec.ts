import { TestBed, waitForAsync } from "@angular/core/testing";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { ProductApiService } from "./product.api.service";
import { IProduct } from "../data/product.model";

describe('Product-ApiService', () => {
    let productApiService: ProductApiService;
    let HttpClient: HttpTestingController;

    const productData: IProduct[] = [{
        "_id": 2,
        "productName": "Lemon Grass",
        "productCode": "HERB-LMG",
        "description": "Used in Soaps and Thai cuisuines.Can be used for tea",
        "price": 80.5,
        "releaseDate": new Date(2021, 8, 7),
        "imageUrl": "assets/images/lemonGrass.jpg",
        "starRating": 2.5
    }]

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [ProductApiService]
        })

        productApiService = TestBed.inject(ProductApiService);
        HttpClient = TestBed.inject(HttpTestingController);
    })
    // Test case for http.get() form apiservice
    it('it should sucessfully get products', waitForAsync(() => {
        
        productApiService.getProducts().subscribe(data => expect(data).toEqual(productData))
        let request = HttpClient.expectOne("api/products");
        request.flush(productData)
    }))

    afterEach(() => HttpClient.verify);

})


// function productData(productData: any) {
//     throw new Error("Function not implemented.");
// }

