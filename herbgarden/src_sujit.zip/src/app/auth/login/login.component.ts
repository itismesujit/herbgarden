import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  pageTitle = "login";
  errorMessage="";
  maskUserName:boolean=true;

  constructor() { }

  ngOnInit(): void {
  }

  login(){
    console.log("Login Sucessful");
  }

  cancel(){
    console.log("Form reset");
    
  }

}
