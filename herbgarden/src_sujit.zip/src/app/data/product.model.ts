
export interface IProduct {
    _id:number,
    productName:string,
    productCode:string,
    description:string,
    price:number,
    imageUrl:string,
    releaseDate:Date,
    starRating:number,
    tags?:string[]
}
