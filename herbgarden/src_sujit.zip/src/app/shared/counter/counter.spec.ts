import { Counter } from "./counter"

xdescribe("Counter", () => {
    let cnt: any = null;
    beforeEach(() => cnt = new Counter()); //Instantiates Counter object inside beforeEach()
    it("Should increment the counter by 1"), () => {
        cnt.increment(); //act
        expect(cnt.counter).toBe(1) //assert
    }

    // end of increment of spec

    it('should decrement the counetr by 1', () => {
        cnt.decrement(); //act
        expect(cnt.counter).toBe(-1) //assert
    });
}) 