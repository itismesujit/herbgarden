export class Calculator {
    
    add(x:number, y:number){
        return x + y;
    }

    multiply(x:number, y:number){
        return x * y;
    }
}