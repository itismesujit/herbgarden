import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { ProductEditComponent } from './product-edit.component';

@Injectable({
  providedIn: 'root'
})
export class ProductEditGuard implements CanDeactivate<ProductEditComponent> {
  canDeactivate(component: ProductEditComponent): any {
    if (component.productForm.dirty) {
      const prodName = component.product.productName || 'New Product'
      return confirm('Would you like to navigate and loose all changes to '+ prodName)
    }
      return true;
  }

}
