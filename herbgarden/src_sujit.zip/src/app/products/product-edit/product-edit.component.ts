import { Component, ElementRef, OnInit, ViewChildren } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { NumberValidator } from '../../shared/validators/number.validator';
import { fromEvent, merge, Observable, Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductApiService } from '../../services/product.api.service';
import { ProductDataService } from 'src/app/data/product.data';
import { IProduct } from 'src/app/data/product.model';
import { GenericValidator } from 'src/app/shared/validators/generic-validator';


@Component({
  selector: 'app-product-edit',
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.css']
})
export class ProductEditComponent implements OnInit {
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements!: ElementRef[];
  pageTitle!: string;
  errorMessage = '';
  productForm!: FormGroup;
  product!: IProduct;
  displayMessage: { [key: string]: string } = {};
  private validationMessages!: { [key: string]: { [key: string]: string } }
  private genericValidator: GenericValidator;
  private sub$!: Subscription;

  constructor(private fb: FormBuilder, private productService: ProductDataService, private router: Router, private route: ActivatedRoute, private apiService: ProductApiService) {
    console.log("From constructor");
    this.validationMessages = {
      productName: {
        required: 'Product name is required',
        minlength: 'product name must be atleast 3 characters',
        maxlength: 'product name must not exceed 20 characters'
      },
      productCode: { required: 'Product code is required' },
      starRating: { range: 'Rate the product between 1(lowest) and 5(highest)' },
      price: { range: 'Ranage of price must be 10 to 1000' }

    };
    this.genericValidator = new GenericValidator(this.validationMessages);
  }

  ngOnInit(): void {
    this.productForm = this.fb.group({
      productName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      productCode: ['', Validators.required],
      price: ['', [Validators.required, NumberValidator.range(10, 1000)]],
      starRating: ['', NumberValidator.range(1, 5)],
      tags: this.fb.array([]),
      description: ''
    });

    this.sub$ = this.route.paramMap.subscribe(
      params => {
        const id = Number(params.get('id'));
        this.getProduct(id)
      }
    );
  }

  ngAfterViewInit() {
    this.productForm.valueChanges.subscribe(value => {
      this.displayMessage = this.genericValidator.processMessage(this.productForm);
    })
  }

  get tags(): FormArray {
    return this.productForm.get('tags') as FormArray
  }

  addTag(): void {
    this.tags.push(new FormControl);
  }
  deleteTag(index: number): void {
    this.tags.removeAt(index);
    this.tags.markAsDirty();
  }

  getProduct(id: number) {
    this.sub$ = this.apiService.getProduct(id).subscribe({
      next: (product: IProduct) => this.displayProduct(product),
      error: err => this.errorMessage = err
    });

  }

  displayProduct(product: IProduct) {
    if (this.productForm) {
      this.productForm.reset();
    }
    this.product = product;
    if (this.product?._id === 0) {
      this.pageTitle = 'Add Product'
    }
    else {
      this.pageTitle = `Edit Product : ${this.product?.productName}`
    }

    this.productForm.patchValue({
      productName: this.product.productName,
      productCode: this.product.productCode,
      price: this.product.price,
      starRating: this.product.starRating,
      description: this.product.description

    });
    this.productForm.setControl('tags', this.fb.array(this.product.tags || []));
  }

  saveProduct() {
    if (this.productForm.valid) {
      if (this.productForm.dirty) {
        const p = { ...this.product, ...this.productForm.value };
        if (p._id === 0) {
          this.apiService.createProduct(p).subscribe(
            {
              next: () => this.OnSaveComplete(),
              error: err => this.errorMessage = err
            });
        }
        else {
          this.apiService.updateProduct(p).subscribe(
            {
              next: () => this.OnSaveComplete(),
              error: err => this.errorMessage = err
            });
        }

      }
      else {
        { { console.log('else case'); } }
        this.OnSaveComplete();
      }
    }
    else {
      this.errorMessage = 'please correct the validation error';
      console.log(this.errorMessage)
    }

  }

  OnSaveComplete(): void {

    this.productForm.reset();
    this.router.navigate(['/products'])
  }

  deleteProduct(): void {
    if (this.product._id === 0) {
      this.OnSaveComplete();
    } else {
      if (confirm(`Do you want to delete the product: ${this.product.productName}`)) {
        console.log(this.product._id, '<===this.product._id');

        this.apiService.deleteProduct(this.product._id).subscribe({
          next: () => this.OnSaveComplete,
          error: err => this.errorMessage = err
        })
      }
    }
  }

  cancelBtn(e: any) {
    this.router.navigate(['/products'])
  }

}