import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProductDataService } from 'src/app/data/product.data';
import { IProduct } from 'src/app/data/product.model';
import { ProductApiService } from 'src/app/services/product.api.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit,AfterViewInit,OnDestroy{
products:IProduct[]=[];
showImage:boolean=true;
  imageWidth=50;
  imageMargin=3;
filteredProducts:IProduct[]=[];
sub!:Subscription;

abc():any{
}


errorMessage:string | undefined;
@ViewChild('input')filteredElementRef:any;

_listFilter!:string;
  set listFilter(value:string){
    this._listFilter=value;
    this.filteredProducts=this.listFilter ? this.performFilter(this.listFilter):this.products;
  }

get listFilter():string{
return this._listFilter;
}

constructor(private productService:ProductDataService,private apiService:ProductApiService){ 
}
  performFilter(filterBy:string):IProduct[]{
    filterBy=filterBy.toLocaleLowerCase();
    return this.products.filter( (product:IProduct)=>{
     return product.productName.toLocaleLowerCase().indexOf(filterBy)!==-1;
    })
  }
  ngOnInit(): void {
   this.sub=this.apiService.getProducts().subscribe(
      {next: product => {this.products = product},
      error:err=> this.errorMessage=err

      }

    );

    
    this.filteredProducts=this.products;
  
    console.log("From OnInit" + this.filteredProducts);
  }
  ngOnChanges(){
  }
  ngAfterViewInit(){
    
    
    
  }

  toggleImage():void{
    this.showImage=!this.showImage;
  }

  pdtMessage=""
  onRatingClicked(message:string){
    this.pdtMessage=message;
  }
  
  selectedProduct:string='none';
  
  getSelected(product:IProduct):boolean{
    return product.productName==this.selectedProduct;
  }
  
  ngOnDestroy(): void {
   
    this.sub.unsubscribe();
  }


}
