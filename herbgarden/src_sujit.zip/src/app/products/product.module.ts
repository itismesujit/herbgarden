import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { ProductEditComponent } from './product-edit/product-edit.component';
import { ProductListComponent } from './product-list/product-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from '../app-routing.module';
import { StarComponent } from '../shared/star/star.component';
import { RxjsComponent } from '../shared/rxjsdemo';
import { ConvertToSpacesPipe } from '../shared/convert-to-spaces.pipes';
import { RouterModule } from '@angular/router';
import { ProductDetailGuard } from './product-detail/product-detail.guard';
import { ProductEditGuard } from './product-edit/product-edit.guard';



@NgModule({
  declarations: [
    ProductDetailComponent,
    ProductEditComponent,
    ProductListComponent,
    StarComponent,
    RxjsComponent,
    ConvertToSpacesPipe,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    RouterModule.forChild([
      {
        path: 'products',
        component: ProductListComponent
      }, {
        path: 'products/:id',
        canActivate: [ProductDetailGuard],
        component: ProductDetailComponent
      },
      {
        path: 'products/:id/edit',
        canDeactivate:[ProductEditGuard],
        canActivate: [ProductDetailGuard],
        component: ProductEditComponent
      }
    ])
  ]
})
export class ProductModule { }
