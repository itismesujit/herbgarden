import { Component, OnDestroy, OnInit } from '@angular/core';
import { IProduct } from '../../data/product.model';
import { Subscription } from 'rxjs';
import { ProductApiService } from '../../services/product.api.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit, OnDestroy {
  pageTitle = 'Product Detail'
  product: IProduct[] | undefined | any;
  imageWidth = 200;
  imageMargin = 1;
  sub$!: Subscription;
  errorMessage!: string;



  constructor(private apiService: ProductApiService, private route: ActivatedRoute, private router: Router) { }
  ngOnInit(): void {
    const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = Number(param)
      this.getProduct(id);
    }
  }


  getProduct(id: number) {
    this.sub$ = this.apiService.getProduct(id).subscribe({
      next: data => this.product = data,
      error: err => this.errorMessage = err
    })
  }

  onBack() {
    this.router.navigate(['/products'])
  }

  onEdit() {
    const param = this.route.snapshot.paramMap.get('id');
    const _id = Number(param)
    if (!isNaN(_id))
      this.router.navigate(['products/' + _id + '/edit'])
  }

  ngOnDestroy(): void {
    if (this.sub$)
      this.sub$.unsubscribe;
  }

}

